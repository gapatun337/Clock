package com.iosclock.widget

import android.graphics.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.cos
import kotlin.math.sin

object ClockRenderer {
    fun render(width: Int = 400, height: Int = 400): Bitmap {
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        val cal = Calendar.getInstance()
        val sec = cal.get(Calendar.SECOND)

        // 1. Draw rounded rect card (#EBEBF0)
        val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#EBEBF0")
            style = Paint.Style.FILL
        }
        val margin = 16f
        val radius = 72f
        val rect = RectF(margin, margin, width - margin, height - margin)
        canvas.drawRoundRect(rect, radius, radius, bgPaint)

        // 2. Draw 60 radial ticks
        val cx = width / 2f
        val cy = height / 2f
        val rOut = width * 0.42f
        val rIn = width * 0.37f

        val tickPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            strokeWidth = 4.5f
            strokeCap = Paint.Cap.ROUND
        }

        for (i in 0 until 60) {
            val angleDeg = i * 6.0
            val angleRad = Math.toRadians(angleDeg - 90.0)

            val x1 = cx + rIn * cos(angleRad).toFloat()
            val y1 = cy + rIn * sin(angleRad).toFloat()
            val x2 = cx + rOut * cos(angleRad).toFloat()
            val y2 = cy + rOut * sin(angleRad).toFloat()

            if (i <= sec) {
                val alpha = (255 * (0.35f + 0.65f * (i.toFloat() / (sec.coerceAtLeast(1)))))).toInt()
                tickPaint.color = Color.argb(alpha.coerceIn(50, 255), 28, 28, 30)
            } else {
                tickPaint.color = Color.argb(35, 28, 28, 30)
            }
            canvas.drawLine(x1, y1, x2, y2, tickPaint)
        }

        // 3. Digital Time Text
        val timePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#1C1C1E")
            textSize = width * 0.22f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }
        val timeStr = SimpleDateFormat("HH:mm", Locale.getDefault()).format(cal.time)
        val textY = cy + (timePaint.textSize / 3f) - 10f
        canvas.drawText(timeStr, cx, textY, timePaint)

        // 4. Date Text
        val datePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#8E8E93")
            textSize = width * 0.05f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }
        val dateStr = SimpleDateFormat("EEE, d MMM", Locale.getDefault()).format(cal.time).uppercase()
        canvas.drawText(dateStr, cx, textY + width * 0.12f, datePaint)

        return bitmap
    }
}
