package com.iosclock.widget

import android.content.Intent
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            gravity = android.view.Gravity.CENTER
            setPadding(40, 40, 40, 40)
            setBackgroundColor(android.graphics.Color.parseColor("#121214"))
        }

        val img = ImageView(this).apply {
            setImageBitmap(ClockRenderer.render(600, 600))
            setOnClickListener {
                val intent = packageManager.getLaunchIntentForPackage("com.google.android.deskclock")
                    ?: Intent(android.provider.AlarmClock.ACTION_SHOW_ALARMS)
                startActivity(intent)
            }
        }
        layout.addView(img, 600, 600)

        val text = TextView(this).apply {
            text = "Виджет 2x2 готов!\n\nЗажмите рабочий стол Pixel 9 -> Виджеты -> iOS Clock Widget 2x2.\n\nНажатие на виджет открывает системные Часы."
            setTextColor(android.graphics.Color.WHITE)
            textSize = 16f
            gravity = android.view.Gravity.CENTER
            setPadding(0, 40, 0, 0)
        }
        layout.addView(text)

        setContentView(layout)
        ClockTickService.startService(this)
    }
}
