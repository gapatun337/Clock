package com.iosclock.widget

import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.IBinder
import android.os.Looper

class ClockTickService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private val tickRunnable = object : Runnable {
        override fun run() {
            val intent = Intent("com.iosclock.widget.ACTION_TICK").apply {
                setPackage(packageName)
            }
            sendBroadcast(intent)
            handler.postDelayed(this, 1000)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        handler.removeCallbacks(tickRunnable)
        handler.post(tickRunnable)
        return START_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacks(tickRunnable)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        fun startService(context: Context) {
            try {
                val intent = Intent(context, ClockTickService::class.java)
                context.startService(intent)
            } catch (e: Exception) {}
        }

        fun stopService(context: Context) {
            try {
                val intent = Intent(context, ClockTickService::class.java)
                context.stopService(intent)
            } catch (e: Exception) {}
        }
    }
}
